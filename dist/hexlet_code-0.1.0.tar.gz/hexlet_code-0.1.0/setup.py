# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/VitaliyShupegin/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/VitaliyShupegin/python-project-lvl1/actions)\n### asciinema\nИгра: 1)"Проверка на чётность" https://asciinema.org/a/t37bHULFVGg7eeJ6jyRCldvey\n\nНеобходимо реализовать игру "Проверка на чётность". Суть игры в следующем: пользователю показывается случайное число. И ему нужно ответить yes, если число чётное, или no — если нечётное.\n\n      2) "Калькулятор"  https://asciinema.org/a/Zf9NcU2OsMrDDCMF4S0kMSLvD\nНеобходимо реализовать игру "Калькулятор". Суть игры в следующем: пользователю показывается случайное математическое выражение, например 35 + 16, которое нужно вычислить и записать правильный ответ.\n\n     3)"НОД"  https://asciinema.org/a/9C3bey6NM6PzY83zHiNaHUpXi\nНеобходимо реализовать игру "наибольший общий делитель (НОД)". Суть игры в следующем: пользователю показывается два случайных числа, например, 25 50. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел.\n \n###  CodeClimate\n<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/maintainability" /></a>\n<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/test_coverage"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/test_coverage" /></a>\n',
    'author': 'vitaliy shupegin',
    'author_email': 'vitaliy.shupegin@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
