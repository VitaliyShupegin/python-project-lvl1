### Hexlet tests and linter status:
[![Actions Status](https://github.com/VitaliyShupegin/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/VitaliyShupegin/python-project-lvl1/actions)
### asciinema
Игра: 1)"Проверка на чётность" https://asciinema.org/a/t37bHULFVGg7eeJ6jyRCldvey

Необходимо реализовать игру "Проверка на чётность". Суть игры в следующем: пользователю показывается случайное число. И ему нужно ответить yes, если число чётное, или no — если нечётное.

      2) "Калькулятор"  https://asciinema.org/a/Zf9NcU2OsMrDDCMF4S0kMSLvD
Необходимо реализовать игру "Калькулятор". Суть игры в следующем: пользователю показывается случайное математическое выражение, например 35 + 16, которое нужно вычислить и записать правильный ответ.

     3)"НОД"  https://asciinema.org/a/9C3bey6NM6PzY83zHiNaHUpXi
Необходимо реализовать игру "наибольший общий делитель (НОД)". Суть игры в следующем: пользователю показывается два случайных числа, например, 25 50. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел.
 
###  CodeClimate
<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/maintainability" /></a>
<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/test_coverage"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/test_coverage" /></a>
