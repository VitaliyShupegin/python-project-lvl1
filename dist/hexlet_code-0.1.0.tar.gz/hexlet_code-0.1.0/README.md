### Hexlet tests and linter status:
[![Actions Status](https://github.com/VitaliyShupegin/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/VitaliyShupegin/python-project-lvl1/actions)
### asciinema
Игра: "Проверка на чётность" https://asciinema.org/a/t37bHULFVGg7eeJ6jyRCldvey
###  CodeClimate
<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/maintainability" /></a>
<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/test_coverage"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/test_coverage" /></a>
