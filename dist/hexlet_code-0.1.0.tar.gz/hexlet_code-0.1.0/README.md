### Hexlet tests and linter status:
[![Actions Status](https://github.com/VitaliyShupegin/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/VitaliyShupegin/python-project-lvl1/actions)
###  CodeClimate
<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/maintainability" /></a>
<a href="https://codeclimate.com/github/VitaliyShupegin/python-project-lvl1/test_coverage"><img src="https://api.codeclimate.com/v1/badges/e349dbb3b9277ec94475/test_coverage" /></a>

### asciinema
Игра: 1)"Проверка на чётность" https://asciinema.org/a/mPV2gG0FziwYPJw5KeIPNP3J7

Необходимо реализовать игру "Проверка на чётность". Суть игры в следующем: пользователю показывается случайное число. И ему нужно ответить yes, если число чётное, или no — если нечётное.

      2) "Калькулятор"  https://asciinema.org/a/0EhFDbia4tqmD35zWrBH2A4iC
Необходимо реализовать игру "Калькулятор". Суть игры в следующем: пользователю показывается случайное математическое выражение, например 35 + 16, которое нужно вычислить и записать правильный ответ.

     3)"НОД"  https://asciinema.org/a/9C3bey6NM6PzY83zHiNaHUpXi
Необходимо реализовать игру "наибольший общий делитель (НОД)". Суть игры в следующем: пользователю показывается два случайных числа, например, 25 50. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел.

    4) "Арифметическая прогрессия"  https://asciinema.org/a/ynsAe5PEEHnOUW5gjDWnu8jJk
  
 Показываем игроку ряд чисел, образующий арифметическую прогрессию, заменив любое из чисел двумя точками. Игрок должен определить это число.
 
   5) "Простое ли число?"  https://asciinema.org/a/7ENsiwdiEXBv8NkHdX5R3OQQ1

Ответьте "да", если данное число является простым. В противном случае ответьте "нет".


